// 🌱 FarmDirect Marketplace Feed (Desktop & Mobile View - Bilingual English / हिन्दी)
import { Icons } from '../lib/icons.js';
import { LanguageManager } from '../lib/translations.js';
import { resolveCropImages, getCropSvgFallback } from '../lib/cropImages.js';

export function renderMarketplaceFeed(container, { crops, onSelectCrop, onFilterChange, onOpenBuyerOrders, currentCategory = 'All' }) {
  const { t } = LanguageManager;
  const currentLang = LanguageManager.getCurrentLanguage();

  const categories = [
    { name: 'All', en: 'All Crops', hi: 'सभी फसलें', icon: '🌾' },
    { name: 'Pulses', en: 'Pulses', hi: 'दालें', icon: '🫘' },
    { name: 'Grains', en: 'Grains', hi: 'अनाज', icon: '🌾' },
    { name: 'Spices', en: 'Spices', hi: 'मसाले', icon: '🌶️' },
    { name: 'Oilseeds', en: 'Oilseeds', hi: 'तिलहन', icon: '🌻' },
    { name: 'Organic', en: 'Organic', hi: 'जैविक', icon: '🌿' }
  ];

  container.innerHTML = `
    <div class="app-container">
      <!-- Left Sidebar (Desktop View) -->
      <aside class="filter-sidebar">
        <!-- Quick My Orders Box for Buyers -->
        <div style="margin-bottom:1.25rem; padding:0.85rem; background:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,0.03);">
          <div style="font-size:0.75rem; font-weight:700; color:#15803d; margin-bottom:0.4rem; display:flex; align-items:center; gap:5px;">
            <span>📦</span>
            <span>${currentLang === 'hi' ? 'ऑर्डर ट्रैकिंग' : 'Buyer Dashboard'}</span>
          </div>
          <button id="btn-sidebar-my-orders" style="width:100%; padding:0.55rem 0.75rem; background:#16a34a; color:#ffffff; border:none; border-radius:8px; font-weight:700; font-size:0.82rem; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:6px; box-shadow:0 2px 6px rgba(22,163,74,0.25);">
            <span>📦</span>
            <span>${currentLang === 'hi' ? 'मेरे ऑर्डर देखें' : 'My Orders & Tracking'}</span>
          </button>
        </div>

        <div class="sidebar-title">${t('categoriesLabel')}</div>
        <div class="category-list" id="sidebar-categories">
          ${categories.map(cat => `
            <div class="category-nav-item ${currentCategory === cat.name ? 'active' : ''}" data-category="${cat.name}">
              <span style="font-size:1.1rem;">${cat.icon}</span>
              <div style="display:flex; flex-direction:column; line-height:1.15;">
                <span style="font-weight:600;">${currentLang === 'hi' ? cat.hi : cat.en}</span>
                <span style="font-size:0.68rem; color:#94a3b8;">${currentLang === 'hi' ? cat.en : cat.hi}</span>
              </div>
            </div>
          `).join('')}
        </div>

        <div class="sidebar-title" style="margin-top:1.5rem;">${t('filtersLabel')}</div>

        <!-- Price Range Slider -->
        <div class="filter-section">
          <div class="filter-label">
            <span>${t('priceRangeLabel')}</span>
            <span id="price-range-val" style="color:#15803d; font-weight:700;">₹10 - ₹100</span>
          </div>
          <input
            type="range"
            id="filter-price-slider"
            class="filter-range-slider"
            min="10"
            max="120"
            value="100"
          />
        </div>

        <!-- Quantity Filter -->
        <div class="filter-section">
          <label class="filter-label">${t('quantityLabel')}</label>
          <select id="filter-quantity" class="filter-select">
            <option value="all">${t('anyQuantity')}</option>
            <option value="small">${t('qtySmall')}</option>
            <option value="medium">${t('qtyMedium')}</option>
            <option value="bulk">${t('qtyBulk')}</option>
          </select>
        </div>

        <!-- Quality / Grade Filter -->
        <div class="filter-section">
          <label class="filter-label">${t('qualityLabel')}</label>
          <select id="filter-grade" class="filter-select">
            <option value="all">${t('anyGrade')}</option>
            <option value="Grade A">${t('gradeA')}</option>
            <option value="Organic">${t('gradeOrganic')}</option>
          </select>
        </div>

        <!-- Harvest Date -->
        <div class="filter-section">
          <label class="filter-label">${t('harvestLabel')}</label>
          <select id="filter-harvest" class="filter-select">
            <option value="all">${t('anyDate')}</option>
            <option value="today">${t('harvestToday')}</option>
            <option value="recent">${t('harvestRecent')}</option>
          </select>
        </div>

        <button id="btn-reset-filters" style="width:100%; padding:0.5rem; font-size:0.8rem; color:#64748b; border:1px dashed #cbd5e1; border-radius:8px; margin-top:0.5rem; cursor:pointer;">
          ${t('btnResetFilters')}
        </button>
      </aside>

      <!-- Main Feed Content Area -->
      <main class="main-content">
        <!-- Top Category Chips & Sort Controls -->
        <div class="content-top-bar">
          <div class="chips-scroll-wrap" id="top-chips-row">
            ${categories.map(cat => `
              <button class="category-chip ${currentCategory === cat.name ? 'active' : ''}" data-category="${cat.name}">
                <span>${cat.icon}</span>
                <span>${currentLang === 'hi' ? cat.hi : cat.en}</span>
              </button>
            `).join('')}
          </div>

          <div class="sort-dropdown-wrap">
            <span style="font-size:0.8rem; color:#64748b; font-weight:600;">${t('sortBy')}:</span>
            <select id="sort-crops-select" class="sort-select">
              <option value="latest">${t('sortLatest')}</option>
              <option value="price_asc">${t('sortPriceLowHigh')}</option>
              <option value="price_desc">${t('sortPriceHighLow')}</option>
              <option value="rating">${t('sortTopRated')}</option>
            </select>
          </div>
        </div>

        <!-- Grid of Produce Cards -->
        <div class="listings-grid" id="produce-grid">
          ${crops.length === 0 ? `
            <div style="grid-column: 1 / -1; padding: 3rem; text-align:center; background:#ffffff; border-radius:16px; border:1px solid #e2e8f0;">
              <span style="font-size:3rem; display:block; margin-bottom:0.75rem;">🌱</span>
              <h3 style="font-size:1.25rem; font-weight:700; color:#0f172a; margin-bottom:0.4rem;">${t('noProduceFound')}</h3>
              <p style="color:#64748b; font-size:0.9rem; margin-bottom:1.25rem;">${t('noProduceDesc')}</p>
              <button id="empty-reset-btn" class="btn-primary-green" style="margin:0 auto;">${t('btnResetFilters')}</button>
            </div>
          ` : crops.map(crop => {
            const cropImgs = resolveCropImages(crop.title, crop.category, crop.images);
            const primaryImg = cropImgs[0];
            const fallbackDataUri = getCropSvgFallback(crop.title, crop.category);

            return `
            <div class="crop-card" data-crop-id="${crop.id}">
              <div class="card-image-wrap">
                <img 
                  src="${primaryImg}" 
                  alt="${crop.title}" 
                  class="card-img" 
                  loading="lazy" 
                  onerror="this.onerror=null; this.src='${fallbackDataUri}'"
                />
                <div class="badge-grade">
                  <span style="width:12px; height:12px; color:#15803d; display:inline-block;">${Icons.check}</span>
                  ${crop.quality_grade || 'Grade A'}
                </div>
                ${crop.tags?.[0] ? `<div class="badge-tag">${crop.tags[0]}</div>` : ''}
              </div>

              <div class="card-body">
                <div class="card-header-row">
                  <h3 class="card-title">${crop.title}</h3>
                </div>

                <div class="card-qty">${crop.quantity_available?.toLocaleString()} ${crop.unit || 'kg'} ${t('available')}</div>

                <div class="card-price-row">
                  <span class="card-price">₹${crop.price_per_unit}</span>
                  <span class="card-unit">/ ${crop.unit || 'kg'}</span>
                </div>

                <div class="card-location">
                  <span>${Icons.mapPin}</span>
                  <span>${crop.location.split(',')[0]}, ${crop.distance_km || 12} km</span>
                </div>

                <div class="card-divider"></div>

                <div class="card-footer">
                  <div class="farmer-tag">
                    <div class="farmer-tag-avatar-badge" style="width:26px; height:26px; border-radius:50%; background:#dcfce7; color:#15803d; display:inline-flex; align-items:center; justify-content:center; font-size:0.85rem; border:1px solid #86efac; flex-shrink:0;">
                      👨‍🌾
                    </div>
                    <div>
                      <div class="farmer-tag-name">${crop.farmer_name}</div>
                      <div class="farmer-tag-rating">
                        <span style="width:12px; height:12px; display:inline-block;">${Icons.star}</span>
                        <span>${crop.farmer_rating || '4.6'}</span>
                        <span style="color:#94a3b8; font-weight:400;">(${crop.farmer_reviews_count || '25'})</span>
                      </div>
                    </div>
                  </div>

                  <span class="harvest-tag">${crop.harvest_date || (currentLang === 'hi' ? 'ताजा कटाई' : 'Fresh Harvest')}</span>
                </div>
              </div>
            </div>
            `;
          }).join('')}
        </div>
      </main>
    </div>
  `;

  // Attach card click handlers
  container.querySelectorAll('.crop-card').forEach(card => {
    card.addEventListener('click', () => {
      const cropId = card.dataset.cropId;
      const crop = crops.find(c => c.id === cropId);
      if (crop) onSelectCrop(crop);
    });
  });

  // Category sidebar clicks
  container.querySelectorAll('.category-nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const cat = item.dataset.category;
      onFilterChange({ category: cat });
    });
  });

  // Top category chips clicks
  container.querySelectorAll('.category-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const cat = chip.dataset.category;
      onFilterChange({ category: cat });
    });
  });

  // Price slider
  const slider = container.querySelector('#filter-price-slider');
  const priceValText = container.querySelector('#price-range-val');
  slider.addEventListener('input', (e) => {
    const val = e.target.value;
    priceValText.innerText = `₹10 - ₹${val}`;
    onFilterChange({ maxPrice: Number(val) });
  });

  // Sort dropdown
  container.querySelector('#sort-crops-select').addEventListener('change', (e) => {
    onFilterChange({ sort: e.target.value });
  });

  // Grade filter
  container.querySelector('#filter-grade').addEventListener('change', (e) => {
    onFilterChange({ grade: e.target.value });
  });

  // Quantity filter
  container.querySelector('#filter-quantity').addEventListener('change', (e) => {
    onFilterChange({ quantityRange: e.target.value });
  });

  // Quick My Orders Button in Sidebar
  container.querySelector('#btn-sidebar-my-orders')?.addEventListener('click', () => {
    if (onOpenBuyerOrders) onOpenBuyerOrders();
  });

  // Reset filters
  const resetBtn = container.querySelector('#btn-reset-filters');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      onFilterChange({ reset: true });
    });
  }

  const emptyResetBtn = container.querySelector('#empty-reset-btn');
  if (emptyResetBtn) {
    emptyResetBtn.addEventListener('click', () => {
      onFilterChange({ reset: true });
    });
  }
}
