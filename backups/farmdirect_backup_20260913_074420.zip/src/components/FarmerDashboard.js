// 🌱 FarmDirect Farmer Management & Intelligence Dashboard (Screens 10 & 7)
import { Icons } from '../lib/icons.js';
import { FarmDirectApi } from '../lib/supabase.js';
import { LanguageManager } from '../lib/translations.js';
import { resolveCropImages, getCropSvgFallback } from '../lib/cropImages.js';

export function renderFarmerDashboard(container, { farmerUser, onOpenAddCrop, onEditCrop, onSelectCrop }) {
  const { t } = LanguageManager;
  let activeTab = 'my_listings';
  let farmerCrops = [];
  let allMarketCrops = [];
  let incomingOrders = [];

  async function loadDataAndRender() {
    farmerCrops = await FarmDirectApi.getFarmerCrops(farmerUser?.id, farmerUser?.name);
    allMarketCrops = await FarmDirectApi.getCrops();
    incomingOrders = await FarmDirectApi.getFarmerOrders(farmerUser?.id);

    // Dynamic stats computation for current farmer
    const totalProduce = farmerCrops.reduce((acc, c) => acc + (Number(c.quantity_available) || 0), 0);
    const totalSold = incomingOrders.reduce((acc, o) => acc + (Number(o.quantity) || 0), 0);
    const totalRevenue = incomingOrders.reduce((acc, o) => acc + (Number(o.total_amount) || 0), 0);

    container.innerHTML = `
      <div class="farmer-layout">
        <!-- Farmer Sidebar (Matches Screen 10) -->
        <aside class="farmer-sidebar">
          <div style="display:flex; align-items:center; gap:0.6rem; margin-bottom:1.25rem; padding-bottom:0.75rem; border-bottom:1px solid #e2e8f0;">
            <img 
              src="/logo.png" 
              alt="FarmDirect Logo" 
              style="width:34px; height:34px; border-radius:8px; object-fit:contain; box-shadow:0 2px 6px rgba(22, 163, 74, 0.2);"
            />
            <div>
              <div style="font-weight:900; font-size:1.05rem; color:#14532d; letter-spacing:-0.3px;">FarmDirect</div>
              <div style="font-size:0.7rem; color:#64748b; font-weight:600;">${t('farmerPortalLabel')}</div>
            </div>
          </div>
          <nav class="farmer-nav-list">
            <button class="farmer-nav-item ${activeTab === 'home_feed' ? 'active' : ''}" data-tab="home_feed">
              <span>${Icons.home}</span>
              <span>${t('navHomeFeed')}</span>
            </button>

            <button class="farmer-nav-item ${activeTab === 'my_listings' ? 'active' : ''}" data-tab="my_listings">
              <span>${Icons.list}</span>
              <span>${t('navMyListings')} (${farmerCrops.length})</span>
            </button>

            <button class="farmer-nav-item ${activeTab === 'my_orders' ? 'active' : ''}" data-tab="my_orders">
              <span>${Icons.packageCheck}</span>
              <span>${t('navMyOrders')} (${incomingOrders.length})</span>
            </button>

            <button class="farmer-nav-item ${activeTab === 'ai_intel' ? 'active' : ''}" data-tab="ai_intel">
              <span>${Icons.trendingUp}</span>
              <span style="display:flex; align-items:center; gap:6px;">
                ${t('navPriceIntel')}
                <span style="font-size:0.68rem; font-weight:700; background:#dcfce7; color:#15803d; padding:1px 6px; border-radius:9999px; border:1px solid #bbf7d0;">${t('badgeComingSoonShort')}</span>
              </span>
            </button>
          </nav>

          <!-- Quick Farm Verification Card -->
          <div style="background:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; padding:0.85rem; font-size:0.78rem;">
            <div style="font-weight:700; color:#15803d; display:flex; align-items:center; gap:4px; margin-bottom:4px;">
              <span>${Icons.check}</span> ${t('verifiedFarmer')}
            </div>
            <div style="color:#334155;">${t('enamNode')}: Meerut Mandi</div>
            <div style="color:#64748b; font-size:0.72rem; margin-top:2px;">ID: #FD-FRM-${farmerUser?.id?.slice(-5) || '9218'}</div>
          </div>
        </aside>

        <!-- Farmer Main Area -->
        <main class="main-content" style="flex:1;">
          <!-- Top Action Bar -->
          <div class="farmer-action-bar">
            <div>
              <h2 style="font-size:1.4rem; font-weight:800; color:#0f172a;">
                ${activeTab === 'my_listings' ? t('dashMyListings') :
                  activeTab === 'my_orders' ? t('dashMyOrders') :
                  activeTab === 'ai_intel' ? t('dashPriceIntel') : t('dashHomeFeed')}
              </h2>
              <p style="font-size:0.85rem; color:#64748b;">
                ${t('dashWelcome')} ${farmerUser?.name} • ${farmerUser?.location}
              </p>
            </div>

            <button id="btn-add-crop-action" class="btn-primary-green" style="font-size:0.92rem; padding:0.7rem 1.4rem;">
              <span style="width:16px; height:16px; display:inline-block;">${Icons.plus}</span>
              ${t('btnAddCrop')}
            </button>
          </div>

          <!-- Farmer Analytics Dashboard Cards (Matches Section 13 in Requirements) -->
          <div class="analytics-cards-grid">
            <div class="analytics-stat-card">
              <div class="stat-header">${t('statTotalProduce')}</div>
              <div class="stat-value">${totalProduce.toLocaleString()} <span style="font-size:1rem; font-weight:500; color:#64748b;">kg</span></div>
              <div class="stat-trend">${t('statProduceTrend')}</div>
            </div>

            <div class="analytics-stat-card">
              <div class="stat-header">${t('statProduceSold')}</div>
              <div class="stat-value">${totalSold.toLocaleString()} <span style="font-size:1rem; font-weight:500; color:#64748b;">kg</span></div>
              <div class="stat-trend" style="color:#15803d;">↑ 72% ${t('statFulfillment')}</div>
            </div>

            <div class="analytics-stat-card">
              <div class="stat-header">${t('statRemainingStock')}</div>
              <div class="stat-value">${farmerCrops.reduce((a, c) => a + c.quantity_available, 0)} <span style="font-size:1rem; font-weight:500; color:#64748b;">kg</span></div>
              <div class="stat-trend" style="color:#d97706;">${t('statStockReady')}</div>
            </div>

            <div class="analytics-stat-card">
              <div class="stat-header">${t('statTotalRevenue')}</div>
              <div class="stat-value" style="color:#15803d;">₹${totalRevenue.toLocaleString()}</div>
              <div class="stat-trend">${t('statAvgRealised')}</div>
            </div>
          </div>

          <!-- AI Decision Support Banner (From Section 7 & 8) -->
          <div class="ai-advice-banner">
            <div class="ai-advice-content">
              <h4>
                <span style="width:18px; height:18px; display:inline-block;">${Icons.trendingUp}</span>
                ${t('aiAdviceTitle')}
              </h4>
              <p>
                ${t('aiAdviceDesc')} <strong style="color:#15803d;">${t('aiAdviceAction')}</strong>
              </p>
            </div>
            <button id="btn-quick-list-recommendation" style="background:#ffffff; color:#14532d; font-weight:700; font-size:0.82rem; padding:0.5rem 1rem; border-radius:8px; white-space:nowrap;">
              ${t('btnQuickList')}
            </button>
          </div>

          <!-- TAB CONTENT: MY LISTINGS -->
          ${activeTab === 'my_listings' ? `
            ${farmerCrops.length === 0 ? `
              <div style="padding: 3.5rem 1.5rem; text-align:center; background:#ffffff; border-radius:16px; border:1px solid #e2e8f0; box-shadow:var(--shadow-sm);">
                <span style="font-size:3.5rem; display:block; margin-bottom:0.75rem;">🌾</span>
                <h3 style="font-size:1.35rem; font-weight:800; color:#0f172a; margin-bottom:0.4rem;">${t('noProduceListed')}</h3>
                <p style="color:#64748b; font-size:0.92rem; max-width:480px; margin:0 auto 1.5rem auto;">
                  ${t('noProduceListedDesc')}
                </p>
                <button id="btn-empty-add-crop" class="btn-primary-green" style="margin:0 auto; font-size:0.95rem; padding:0.75rem 1.5rem;">
                  <span style="width:18px; height:18px; display:inline-block;">${Icons.plus}</span>
                  ${t('btnAddFirstCrop')}
                </button>
              </div>
            ` : `
            <div class="listings-grid">
              ${farmerCrops.map(crop => {
                const cropImgs = resolveCropImages(crop.title, crop.category, crop.images);
                const primaryImg = cropImgs[0];
                const fallbackSvg = getCropSvgFallback(crop.title, crop.category);

                return `
                <div class="crop-card" data-crop-id="${crop.id}">
                  <div class="card-image-wrap">
                    <img 
                      src="${primaryImg}" 
                      alt="${crop.title}" 
                      class="card-img" 
                      loading="lazy" 
                      onerror="this.onerror=null; this.src='${fallbackSvg}'"
                    />
                    <div class="badge-grade">
                      ${Icons.check} ${crop.quality_grade || 'Grade A'}
                    </div>
                    <div class="badge-tag" style="background:#15803d;">${t('activeListing')}</div>
                  </div>

                  <div class="card-body">
                    <div class="card-header-row">
                      <h3 class="card-title">${crop.title}</h3>
                    </div>

                    <div class="card-qty">${crop.quantity_available?.toLocaleString()} ${crop.unit || 'kg'} ${t('inInventory')}</div>

                    <div class="card-price-row">
                      <span class="card-price">₹${crop.price_per_unit}</span>
                      <span class="card-unit">/ ${crop.unit || 'kg'}</span>
                    </div>

                    <div class="card-location">
                      <span>${Icons.mapPin}</span>
                      <span>${crop.location}</span>
                    </div>

                    <div class="card-divider"></div>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                      <span style="font-size:0.75rem; color:#64748b;">${crop.harvest_date || t('harvestRecently')}</span>
                      <div style="display:flex; gap:0.4rem;">
                        <button class="btn-farmer-edit" data-edit-id="${crop.id}" style="padding:4px 10px; font-size:0.75rem; color:#15803d; border:1px solid #86efac; background:#f0fdf4; border-radius:6px; font-weight:700; cursor:pointer;">
                          ✏️ ${t('btnEditListing') || 'Edit'}
                        </button>
                        <button class="btn-farmer-delete" data-delete-id="${crop.id}" style="padding:4px 8px; font-size:0.75rem; color:#ef4444; border:1px solid #fecaca; border-radius:6px; font-weight:600; cursor:pointer;">
                          ${t('btnDeleteCrop')}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                `;
              }).join('')}
            </div>
            `}
          ` : ''}

          <!-- TAB CONTENT: MY ORDERS (Incoming orders from buyers) -->
          ${activeTab === 'my_orders' ? `
            <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:16px; overflow:hidden; box-shadow:var(--shadow-sm);">
              ${incomingOrders.length === 0 ? `
                <div style="padding:3.5rem 1.5rem; text-align:center; color:#64748b;">
                  <span style="font-size:3rem; display:block; margin-bottom:0.5rem;">📦</span>
                  <h4 style="font-size:1.1rem; font-weight:700; color:#0f172a; margin-bottom:0.25rem;">No Incoming Orders Yet</h4>
                  <p style="font-size:0.85rem;">When buyers place orders on your produce, they will instantly appear here with live tracking.</p>
                </div>
              ` : `
              <div style="overflow-x:auto;">
                <table style="width:100%; border-collapse:collapse; font-size:0.85rem; text-align:left;">
                  <thead>
                    <tr style="background:#f8fafc; border-bottom:1px solid #e2e8f0; color:#64748b; font-weight:600;">
                      <th style="padding:1rem;">${t('orderIdLabel')}</th>
                      <th style="padding:1rem;">${t('buyerLabel')}</th>
                      <th style="padding:1rem;">${t('produceLabel')}</th>
                      <th style="padding:1rem;">${t('qtyLabel')}</th>
                      <th style="padding:1rem;">${t('totalLabel')} (₹)</th>
                      <th style="padding:1rem;">${t('statusLabel')}</th>
                      <th style="padding:1rem; min-width:180px;">${t('actionLabel')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${incomingOrders.map(order => {
                      const st = (order.status || 'placed').toLowerCase();
                      let badgeBg = 'background:#fef3c7; color:#b45309; border:1px solid #fde68a;';
                      let statusText = '🟡 Order Placed';

                      if (st.includes('deliver')) {
                        badgeBg = 'background:#dcfce7; color:#15803d; border:1px solid #86efac;';
                        statusText = '🎉 Delivered';
                      } else if (st.includes('out') || st.includes('transit') || st.includes('dispatch')) {
                        badgeBg = 'background:#ede9fe; color:#6d28d9; border:1px solid #c4b5fd;';
                        statusText = '🚚 Out for Delivery';
                      } else if (st.includes('confirm')) {
                        badgeBg = 'background:#dbeafe; color:#1d4ed8; border:1px solid #93c5fd;';
                        statusText = '✅ Confirmed';
                      } else if (st.includes('cancel')) {
                        badgeBg = 'background:#fee2e2; color:#b91c1c; border:1px solid #fca5a5;';
                        statusText = '❌ Cancelled';
                      }

                      return `
                      <tr style="border-bottom:1px solid #f1f5f9;">
                        <td style="padding:1rem; font-weight:700; color:#0f172a;">
                          #${order.id}
                          <div style="font-size:0.72rem; color:#94a3b8; font-weight:normal;">${order.date || 'Today'}</div>
                        </td>
                        <td style="padding:1rem;">
                          <div style="font-weight:600; color:#0f172a;">${order.buyer_name}</div>
                          <div style="font-size:0.75rem; color:#64748b;">${order.buyer_phone || '+91 98765 88990'}</div>
                        </td>
                        <td style="padding:1rem;">
                          <div style="font-weight:700; color:#0f172a;">${order.crop_title}</div>
                          <div style="font-size:0.75rem; color:#64748b;">${order.delivery_option}</div>
                        </td>
                        <td style="padding:1rem; font-weight:600;">${order.quantity} ${order.unit || 'kg'}</td>
                        <td style="padding:1rem; font-weight:800; color:#15803d; font-size:0.95rem;">₹${order.total_amount}</td>
                        <td style="padding:1rem;">
                          <span style="display:inline-flex; align-items:center; gap:4px; padding:4px 10px; border-radius:9999px; font-size:0.75rem; font-weight:700; ${badgeBg}">
                            ${statusText}
                          </span>
                        </td>
                        <td style="padding:1rem;">
                          <div style="display:flex; align-items:center; gap:6px; flex-wrap:wrap;">
                            ${st === 'placed' || st === 'order placed' ? `
                              <button class="btn-quick-status" data-order-id="${order.id}" data-target-status="Confirmed" style="padding:5px 10px; background:#16a34a; color:#ffffff; border:none; border-radius:6px; font-weight:700; font-size:0.75rem; cursor:pointer;">
                                ✓ Confirm
                              </button>
                            ` : st.includes('confirm') ? `
                              <button class="btn-quick-status" data-order-id="${order.id}" data-target-status="Out for Delivery" style="padding:5px 10px; background:#7c3aed; color:#ffffff; border:none; border-radius:6px; font-weight:700; font-size:0.75rem; cursor:pointer;">
                                🚚 Dispatch
                              </button>
                            ` : st.includes('out') || st.includes('transit') || st.includes('preparing') ? `
                              <button class="btn-quick-status" data-order-id="${order.id}" data-target-status="Delivered" style="padding:5px 10px; background:#15803d; color:#ffffff; border:none; border-radius:6px; font-weight:700; font-size:0.75rem; cursor:pointer;">
                                🎉 Mark Delivered
                              </button>
                            ` : `
                              <span style="font-size:0.75rem; color:#15803d; font-weight:700;">✓ Completed</span>
                            `}

                            <select class="order-status-select" data-order-id="${order.id}" style="padding:3px 6px; border-radius:6px; font-size:0.72rem; border:1px solid #cbd5e1; background:#f8fafc; color:#475569; cursor:pointer;">
                              <option value="placed" ${st === 'placed' ? 'selected' : ''}>Placed</option>
                              <option value="Confirmed" ${st.includes('confirm') ? 'selected' : ''}>Confirmed</option>
                              <option value="Out for Delivery" ${st.includes('out') || st.includes('transit') ? 'selected' : ''}>Out for Delivery</option>
                              <option value="Delivered" ${st.includes('deliver') ? 'selected' : ''}>Delivered</option>
                              <option value="Cancelled" ${st.includes('cancel') ? 'selected' : ''}>Cancelled</option>
                            </select>
                          </div>
                        </td>
                      </tr>
                      `;
                    }).join('')}
                  </tbody>
                </table>
              </div>
              `}
            </div>
          ` : ''}

          <!-- TAB CONTENT: PRICE INTELLIGENCE & AI (COMING SOON SHOWCASE) -->
          ${activeTab === 'ai_intel' ? `
            <div style="background:#ffffff; border-radius:20px; padding:2.5rem 1.75rem; border:1px solid #e2e8f0; box-shadow:var(--shadow-sm); text-align:center;">
              <div style="display:inline-flex; align-items:center; gap:0.5rem; background:#f0fdf4; color:#15803d; padding:0.4rem 1.1rem; border-radius:9999px; font-weight:700; font-size:0.85rem; margin-bottom:1.25rem; border:1px solid #bbf7d0;">
                <span style="font-size:1.1rem;">🚀</span>
                <span>${t('badgeComingSoon')}</span>
              </div>

              <h3 style="font-size:1.55rem; font-weight:800; color:#0f172a; margin-bottom:0.75rem;">
                ${t('priceIntelComingSoonTitle')}
              </h3>

              <p style="color:#64748b; font-size:0.95rem; max-width:620px; margin:0 auto 2rem auto; line-height:1.6;">
                ${t('priceIntelComingSoonSubtitle')}
              </p>

              <!-- Feature Highlights Grid -->
              <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:1.25rem; text-align:left; max-width:850px; margin:0 auto 2.25rem auto;">
                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:1.25rem;">
                  <div style="font-size:1.6rem; margin-bottom:0.5rem;">📊</div>
                  <h4 style="font-size:0.95rem; font-weight:700; color:#0f172a; margin-bottom:0.3rem;">${t('priceIntelFeature1Title')}</h4>
                  <p style="font-size:0.82rem; color:#64748b; line-height:1.45;">${t('priceIntelFeature1Desc')}</p>
                </div>

                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:1.25rem;">
                  <div style="font-size:1.6rem; margin-bottom:0.5rem;">🤖</div>
                  <h4 style="font-size:0.95rem; font-weight:700; color:#0f172a; margin-bottom:0.3rem;">${t('priceIntelFeature2Title')}</h4>
                  <p style="font-size:0.82rem; color:#64748b; line-height:1.45;">${t('priceIntelFeature2Desc')}</p>
                </div>

                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:1.25rem;">
                  <div style="font-size:1.6rem; margin-bottom:0.5rem;">🔔</div>
                  <h4 style="font-size:0.95rem; font-weight:700; color:#0f172a; margin-bottom:0.3rem;">${t('priceIntelFeature3Title')}</h4>
                  <p style="font-size:0.82rem; color:#64748b; line-height:1.45;">${t('priceIntelFeature3Desc')}</p>
                </div>

                <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:14px; padding:1.25rem;">
                  <div style="font-size:1.6rem; margin-bottom:0.5rem;">🛡️</div>
                  <h4 style="font-size:0.95rem; font-weight:700; color:#0f172a; margin-bottom:0.3rem;">${t('priceIntelFeature4Title')}</h4>
                  <p style="font-size:0.82rem; color:#64748b; line-height:1.45;">${t('priceIntelFeature4Desc')}</p>
                </div>
              </div>

              <!-- Action Notify Button -->
              <button id="btn-notify-intel" class="btn-primary-green" style="margin:0 auto; padding:0.8rem 1.8rem; font-size:0.95rem; font-weight:700; border-radius:10px;">
                ${t('btnNotifyMePriceIntel')}
              </button>
            </div>
          ` : ''}

          <!-- TAB CONTENT: HOME FEED (Farmer browsing all crops in Marketplace) -->
          ${activeTab === 'home_feed' ? `
            <div class="listings-grid">
              ${allMarketCrops.map(crop => {
                const cropImgs = resolveCropImages(crop.title, crop.category, crop.images);
                const primaryImg = cropImgs[0];
                const fallbackSvg = getCropSvgFallback(crop.title, crop.category);

                return `
                <div class="crop-card" data-crop-id="${crop.id}">
                  <div class="card-image-wrap">
                    <img 
                      src="${primaryImg}" 
                      alt="${crop.title}" 
                      class="card-img" 
                      loading="lazy" 
                      onerror="this.onerror=null; this.src='${fallbackSvg}'"
                    />
                    <div class="badge-grade">${Icons.check} ${crop.quality_grade || 'Grade A'}</div>
                  </div>
                  <div class="card-body">
                    <h3 class="card-title">${crop.title}</h3>
                    <div class="card-qty">${crop.quantity_available} kg ${t('available')}</div>
                    <div class="card-price-row"><span class="card-price">₹${crop.price_per_unit}</span> / kg</div>
                    <div class="card-location" style="font-size:0.75rem; color:#64748b; margin-top:4px;">
                      <span>${Icons.mapPin}</span>
                      <span>${crop.location}</span>
                    </div>
                  </div>
                </div>
                `;
              }).join('')}
            </div>
          ` : ''}
        </main>

        <!-- Floating Add Crop Button (Desktop/Mobile) -->
        <button id="floating-farmer-add-btn" class="floating-add-btn">
          <span style="width:20px; height:20px; display:inline-block;">${Icons.plus}</span>
          Add Listing
        </button>
      </div>
    `;

    // Tab switching
    container.querySelectorAll('.farmer-nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        activeTab = btn.dataset.tab;
        loadDataAndRender();
      });
    });

    // Price intelligence notification button
    container.querySelector('#btn-notify-intel')?.addEventListener('click', () => {
      alert(t('priceIntelNotifiedMsg'));
    });

    // Add crop actions
    container.querySelector('#btn-add-crop-action')?.addEventListener('click', onOpenAddCrop);
    container.querySelector('#floating-farmer-add-btn')?.addEventListener('click', onOpenAddCrop);
    container.querySelector('#btn-quick-list-recommendation')?.addEventListener('click', onOpenAddCrop);
    container.querySelector('#btn-empty-add-crop')?.addEventListener('click', onOpenAddCrop);

    // Edit listing action
    container.querySelectorAll('.btn-farmer-edit').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const cropId = btn.dataset.editId;
        const crop = farmerCrops.find(c => String(c.id) === String(cropId));
        if (crop && onEditCrop) {
          onEditCrop(crop);
        }
      });
    });

    // Delete listing action
    container.querySelectorAll('.btn-farmer-delete').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const cropId = btn.dataset.deleteId;
        if (confirm(t('confirmDeleteCrop'))) {
          await FarmDirectApi.deleteCrop(cropId);
          loadDataAndRender();
        }
      });
    });

    // Quick one-click status buttons
    container.querySelectorAll('.btn-quick-status').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const orderId = btn.dataset.orderId;
        const targetStatus = btn.dataset.targetStatus;
        await FarmDirectApi.updateOrderStatus(orderId, targetStatus);
        loadDataAndRender();
      });
    });

    // Order status dropdown select
    container.querySelectorAll('.order-status-select').forEach(select => {
      select.addEventListener('change', async (e) => {
        const orderId = select.dataset.orderId;
        const newStatus = e.target.value;
        await FarmDirectApi.updateOrderStatus(orderId, newStatus);
        loadDataAndRender();
      });
    });

    // Crop card click
    container.querySelectorAll('.crop-card').forEach(card => {
      card.addEventListener('click', () => {
        const cropId = card.dataset.cropId;
        const crop = [...farmerCrops, ...allMarketCrops].find(c => String(c.id) === String(cropId));
        if (crop) onSelectCrop(crop);
      });
    });
  }

  // Listen to cross-window or Supabase real-time updates to orders
  const onOrderUpdate = () => {
    loadDataAndRender();
  };
  window.addEventListener('farmdirect:order_status_updated', onOrderUpdate);

  loadDataAndRender();
}
